import os
from PIL import Image

# Set the directory containing the images
input_dir = r'C:\Users\tygan\Documents\~ School ~\- Projects\Pokemon Identifier\pkmn_identifier\test\fanart'  # Replace with your image folder path
output_dir = r'C:\Users\tygan\Documents\~ School ~\- Projects\Pokemon Identifier\pkmn_identifier\output'  # Replace with the path where you want to save the resized images

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Initialize a counter for naming the images
counter = 1

# Loop over all files in the input directory
for filename in os.listdir(input_dir):
    if filename.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif')):  # Include all relevant image formats
        img_path = os.path.join(input_dir, filename)
        
        # Open an image file
        with Image.open(img_path) as img:
            # Convert RGBA to RGB if necessary
            if img.mode == 'RGBA':
                img = img.convert('RGB')
            
            # Resize the image to 128x128 pixels
            img_resized = img.resize((128, 128))
            
            # Construct the output file path
            output_filename = f'test_image_{counter}.jpg'
            output_path = os.path.join(output_dir, output_filename)
            
            # Save the image as JPG
            img_resized.save(output_path, 'JPEG')
            
            # Increment the counter
            counter += 1

print(f"Resized images saved to {output_dir}")
